var modal = '';

function open_modal(id){
    modal = document.getElementById(id)
    modal.style.display = "block"
}
function close_modal(){
    modal.style.display = "none"
}